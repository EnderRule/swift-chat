//
//  SAMVideoPlayer.swift
//  SAMedia
//
//  Created by sagesse on 27/10/2016.
//  Copyright © 2016 SAGESSE. All rights reserved.
//

import UIKit
import MediaPlayer

///
/// 视频播放器
///
open class SAMVideoPlayer: NSObject {
    
//    // data must be in the form of an audio file understood by CoreAudio
//    public init(contentsOf url: URL) throws {
//        imp = try AVAudioPlayer(contentsOf: url)
//        super.init()
//    }
//
//    public init(data: Data) throws {
//        imp = try AVAudioPlayer(data: data)
//        super.init()
//    }
//
//    // The file type hint is a constant defined in AVMediaFormat.h whose value is a UTI for a file format. e.g. AVFileTypeAIFF.
//    // Sometimes the type of a file cannot be determined from the data, or it is actually corrupt.
//    // The file type hint tells the parser what kind of data to look for so that files which are not self identifying or possibly even corrupt can be successfully parsed.
//    public init(contentsOf url: URL, fileTypeHint utiString: String?) throws {
//        imp = try AVAudioPlayer(contentsOf: url, fileTypeHint: utiString)
//        super.init()
//    }
//    
//    public init(data: Data, fileTypeHint utiString: String?) throws {
//        imp = try AVAudioPlayer(data: data, fileTypeHint: utiString)
//        super.init()
//    }
//    
//    // MARK: - Transport Control
//    
//    // methods that return BOOL return YES on success and NO on failure.
//    // get ready to play the sound. happens automatically on play.
//    open func prepareToPlay() -> Bool  {
//        fatalError()
//    }
//    
//    // sound is played asynchronously.
//    open func play() -> Bool {
//        fatalError()
//    }
//    // play a sound some time in the future. time is an absolute time based on and greater than deviceCurrentTime.
//    open func play(at time: TimeInterval) -> Bool {
//        fatalError()
//    }
//    
//    // pauses playback, but remains ready to play.
//    open func pause() {
//        fatalError()
//    }
//    // stops playback. no longer ready to play.
//    open func stop() {
//        fatalError()
//    }
//    
//    // MARK: - Properties
//
//    // is it playing or not?
//    open var isPlaying: Bool {
//        return imp.isPlaying
//    }
//
//    
//    // returns nil if object was not created with a URL
//    open var url: URL? {
//        return imp.url
//    }
//    
//    // returns nil if object was not created with a data object
//    open var data: Data? {
//        return imp.data
//    }
//
//    // the duration of the sound.
//    open var duration: TimeInterval {
//        return imp.duration
//    }
//    
//    // If the sound is playing, currentTime is the offset into the sound of the current playback position.
//    // If the sound is not playing, currentTime is the offset into the sound where playing would start.
//    open var currentTime: TimeInterval {
//        return imp.currentTime
//    }
//    
//    // returns the current time associated with the output device
//    open var deviceCurrentTime: TimeInterval {
//        return imp.deviceCurrentTime
//    }
//    
//    // "numberOfLoops" is the number of times that the sound will return to the beginning upon reaching the end.
//    // A value of zero means to play the sound just once.
//    // A value of one will result in playing the sound twice, and so on..
//    // Any negative number will loop indefinitely until stopped.
//    open var numberOfLoops: Int {
//        set { return imp.numberOfLoops = newValue }
//        get { return imp.numberOfLoops }
//    }
//    
//    open var numberOfChannels: Int {
//        return imp.numberOfChannels
//    }
//    
//    // the delegate will be sent messages from the AVAudioPlayerDelegate protocol
//    open weak var delegate: AVAudioPlayerDelegate?
//    
//    // set panning. -1.0 is left, 0.0 is center, 1.0 is right.
//    open var pan: Float  {
//        set { return imp.pan = newValue }
//        get { return imp.pan }
//    }
//
//    // The volume for the sound. The nominal range is from 0.0 to 1.0.
//    open var volume: Float  {
//        set { return imp.volume = newValue }
//        get { return imp.volume }
//    }
//    
//    // You must set enableRate to YES for the rate property to take effect. You must set this before calling prepareToPlay.
//    open var enableRate: Bool {
//        set { return imp.enableRate = newValue }
//        get { return imp.enableRate }
//    }
//    
//    // See enableRate. The playback rate for the sound. 1.0 is normal, 0.5 is half speed, 2.0 is double speed.
//    open var rate: Float  {
//        set { return imp.rate = newValue }
//        get { return imp.rate }
//    }
//    
//    
//    // MARK: - Settings
//    
//    
//    // returns a settings dictionary with keys as described in AVAudioSettings.h
//    open var settings: [String : Any] {
//        return imp.settings
//    } 
//    
//    
//    // MARK: - Metering
//    
//    // turns level metering on or off. default is off.
//    open var isMeteringEnabled: Bool {
//        set { return imp.isMeteringEnabled = newValue }
//        get { return imp.isMeteringEnabled }
//    }
//    
//    // call to refresh meter values
//    open func updateMeters()  {
//        return imp.updateMeters()
//    }
//    
//    // returns peak power in decibels for a given channel
//    open func peakPower(forChannel channelNumber: Int) -> Float  {
//        return imp.peakPower(forChannel: channelNumber)
//    }
//    
//    // returns average power in decibels for a given channel
//    open func averagePower(forChannel channelNumber: Int) -> Float  {
//        return imp.averagePower(forChannel: channelNumber)
//    }
//    
//    // MARK: - iVar
//    
//    internal var imp: AVAudioPlayer
}
