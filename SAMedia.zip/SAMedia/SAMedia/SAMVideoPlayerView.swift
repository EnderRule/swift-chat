//
//  SAMVideoPlayerView.swift
//  SAMedia
//
//  Created by sagesse on 27/10/2016.
//  Copyright © 2016 SAGESSE. All rights reserved.
//

import UIKit
import MediaPlayer

///
/// 视频播放器视图
///
open class SAMVideoPlayerView: UIView {
}
